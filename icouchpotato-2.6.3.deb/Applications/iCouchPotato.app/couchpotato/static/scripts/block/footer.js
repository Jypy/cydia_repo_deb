Block.Footer = new Class({

	Extends: BlockBase,

	create: function(){
		var self = this;

		self.el = new Element('div.footer');
	}

});