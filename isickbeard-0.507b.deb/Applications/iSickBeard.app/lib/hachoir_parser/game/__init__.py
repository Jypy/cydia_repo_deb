from lib.hachoir_parser.game.zsnes import ZSNESFile
from lib.hachoir_parser.game.spider_man_video import SpiderManVideoFile
from lib.hachoir_parser.game.laf import LafFile
from lib.hachoir_parser.game.blp import BLP1File, BLP2File