# This file will be patched by setup.py
# The __version__ should be set to the branch name
# (e.g. "trunk" or "0.4.x")

# You MUST use double quotes (so " and not ')

__version__ = "0.7.20"
__baseline__ = "1df2943d05d64915a166e2c97e1eef86f72e3ff3"
